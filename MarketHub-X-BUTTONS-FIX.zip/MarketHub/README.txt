MARKETHUB STARTER

Stack: HTML + CSS + JavaScript + Supabase + GitHub + Render Static Site

FILES
- index.html
- style.css
- script.js
- config.js
- config-supabase.js.example

NEXT SETUP
1. Upload the files to a GitHub repository named MarketHub.
2. Create a Supabase project.
3. Put your Supabase URL and public anon key in config.js.
4. Deploy the repository on Render as a Static Site.
5. Build the Supabase database/authentication and seller/admin features.

IMPORTANT
Do not put a Supabase service_role key in this website. Use only the public anon key in config.js.
The crypto address currently shown is the USDT/TRC20 address supplied for the project.


POST APPROVAL
-------------
Seller posts are now designed to enter a "pending" state.
The admin account marketsaleofficial@gmail.com can open the mobile menu,
choose Admin Dashboard, and approve or reject pending posts.

IMPORTANT:
1. Run SUPABASE-POST-APPROVAL.sql in the Supabase SQL Editor.
2. Make sure the admin email is registered in Supabase Auth as:
   marketsaleofficial@gmail.com
3. A seller-created post stays hidden from public buyers until approved.
4. Never put a Supabase service_role/secret key in config.js.


CRYPTO PLAN FIX
----------------
The Choose Starter/Business/Pro buttons open the crypto payment modal directly.
The page uses versioned JS/config URLs to prevent an older cached script from loading.
If Render is already deployed, redeploy this exact version.


SUBSCRIPTION FOREIGN-KEY FIX
----------------------------
If seller payment submission says:
subscriptions_seller_id_fkey
then the signed-in Auth user did not have a matching row in profiles.

This version automatically creates the profile row before submitting
the subscription. Also run SUPABASE-SUBSCRIPTION-FIX.sql once in Supabase
to make sure the required tables and RLS policies exist.
