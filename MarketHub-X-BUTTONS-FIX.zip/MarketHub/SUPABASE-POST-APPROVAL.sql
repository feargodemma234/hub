-- MarketHub: seller post approval
-- Run this in Supabase SQL Editor.

alter table products
  add column if not exists approval_status text not null default 'pending';

-- Existing demo/old products can remain visible.
update products
set approval_status = 'approved'
where approval_status is null or approval_status = 'pending';

-- Public buyers should only see approved + active products.
drop policy if exists "products_public_read" on products;
create policy "products_public_read"
on products for select
using (active = true and approval_status = 'approved');

-- Sellers can see their own posts, including pending/rejected posts.
drop policy if exists "seller_view_own_products" on products;
create policy "seller_view_own_products"
on products for select
using (auth.uid() = seller_id);

-- Admin can review all posts.
drop policy if exists "admin_view_all_products" on products;
create policy "admin_view_all_products"
on products for select
using (
  lower(coalesce(auth.jwt() ->> 'email','')) = 'marketsaleofficial@gmail.com'
);

-- Admin can approve/reject posts.
drop policy if exists "admin_update_all_products" on products;
create policy "admin_update_all_products"
on products for update
using (
  lower(coalesce(auth.jwt() ->> 'email','')) = 'marketsaleofficial@gmail.com'
)
with check (
  lower(coalesce(auth.jwt() ->> 'email','')) = 'marketsaleofficial@gmail.com'
);

-- Sellers can create posts, but new posts are pending by default.
drop policy if exists "seller_create_products" on products;
create policy "seller_create_products"
on products for insert
with check (
  auth.uid() = seller_id
  and approval_status = 'pending'
);
