const products=[
{id:1,name:'Wireless Earbuds',price:49,category:'electronics',icon:'🎧'},
{id:2,name:'Nike Air Force 1',price:120,category:'fashion',icon:'👟'},
{id:3,name:'Smart Watch',price:79,category:'electronics',icon:'⌚'},
{id:4,name:'MacBook Air M2',price:899,category:'electronics',icon:'💻'},
{id:5,name:'Skin Care Set',price:45,category:'beauty',icon:'🧴'},
{id:6,name:'PS5 Controller',price:65,category:'sports',icon:'🎮'},
{id:7,name:'Modern Lamp',price:39,category:'home',icon:'💡'},
{id:8,name:'Classic Backpack',price:55,category:'fashion',icon:'🎒'}];
const categories=[['all','▦'],['electronics','▱'],['fashion','♢'],['home','⌂'],['beauty','◈'],['sports','◉'],['books','▤'],['vehicles','▰'],['other','•••']];
const plans=[['Starter',5,10,'Perfect for getting started.'],['Business',15,50,'For growing sellers.'],['Pro',30,200,'For serious sellers.']];
let cart=JSON.parse(localStorage.getItem('mh_cart')||'[]');let selectedCategory='all';
const money=n=>`$${n.toFixed(2)}`;
function renderCategories(){document.getElementById('categories').innerHTML=categories.map((c,i)=>`<button class="category ${i===0?'active':''}" data-cat="${c[0]}"><span>${c[1]}</span>${c[0][0].toUpperCase()+c[0].slice(1)}</button>`).join('')}
function renderProducts(list=products){document.getElementById('products').innerHTML=list.length?list.map(p=>`<article class="product"><div class="product-img">${p.icon}</div><div class="product-body"><span class="tag">${p.category}</span><h3>${p.name}</h3><div class="price">${money(p.price)}</div><button class="primary add" data-id="${p.id}">Add to Cart</button></div></article>`).join(''):`<p class="empty">No products found.</p>`}
function renderPlans(){document.getElementById('plans').innerHTML=plans.map((p,i)=>`<article class="plan ${i===1?'popular':''}">${i===1?'<span class="tag">MOST POPULAR</span>':''}<h3>${p[0]}</h3><div class="plan-price">$${p[1]} <small>/month</small></div><p>${p[3]}</p><p>✓ ${p[2]} product listings</p><p>✓ Seller dashboard</p><p>✓ Product management</p><button type="button" class="primary choose" data-plan="${p[0]}">Choose ${p[0]}</button></article>`).join('')}
function save(){localStorage.setItem('mh_cart',JSON.stringify(cart));const count=cart.reduce((a,b)=>a+b.qty,0);document.getElementById('cartCount').textContent=count;document.getElementById('mobileCartCount').textContent=count}
function add(id){let p=products.find(x=>x.id===+id),x=cart.find(x=>x.id===p.id);x?x.qty++:cart.push({...p,qty:1});save()}
function openCart(){let html=cart.length?cart.map(x=>`<div class="cart-row"><span>${x.icon} ${x.name} × ${x.qty}</span><b>${money(x.price*x.qty)}</b></div>`).join(''):'<div class="empty">Your cart is empty.</div>';document.getElementById('cartItems').innerHTML=html;document.getElementById('cartTotal').textContent=money(cart.reduce((a,b)=>a+b.price*b.qty,0));document.getElementById('cartModal').classList.add('show')}
function filter(cat){selectedCategory=cat;document.querySelectorAll('.category').forEach(x=>x.classList.toggle('active',x.dataset.cat===cat));renderProducts(cat==='all'?products:products.filter(p=>p.category===cat));document.getElementById('explore').scrollIntoView({behavior:'smooth'})}
function auth(mode){document.getElementById('authTitle').textContent=mode==='login'?'Log In':'Create Account';document.getElementById('authMessage').textContent='';document.getElementById('authModal').classList.add('show');document.getElementById('authForm').dataset.mode=mode}


const ADMIN_EMAIL = 'marketsaleofficial@gmail.com';

function esc(value){
  return String(value ?? '').replace(/[&<>"']/g, c => ({
    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
  }[c]));
}

async function isAdminUser(){
  if(typeof supabaseClient==='undefined' || !supabaseClient) return false;
  const {data:{user}} = await supabaseClient.auth.getUser();
  return !!user && user.email?.toLowerCase() === ADMIN_EMAIL;
}

let selectedPlan = null;
const PLAN_PRICES = {Starter:5, Business:15, Pro:30};
const PAYMENT_ADDRESS = 'TRzfCcrUmc212VLEYNYVRKtSuYQSnaiU6T';

function openPayment(plan){
  if(!PLAN_PRICES[plan]) return;
  selectedPlan = plan;
  const modal = document.getElementById('paymentModal');
  document.getElementById('paymentTitle').textContent = `${plan} Plan — $${PLAN_PRICES[plan]}/month`;
  document.getElementById('paymentDescription').textContent = `Send $${PLAN_PRICES[plan]} in USDT on TRC20 to the address below. Then enter your transaction hash for admin review.`;
  document.getElementById('paymentTx').value = '';
  document.getElementById('paymentMessage').textContent = '';
  modal.classList.add('show');
  modal.style.display = 'flex';
}

async function submitSubscriptionPayment(){
  const msg = document.getElementById('paymentMessage');
  const tx = document.getElementById('paymentTx').value.trim();
  if(!selectedPlan) return;
  if(!tx){msg.textContent='Enter your transaction hash first.'; return;}
  if(!supabaseClient){msg.textContent='Supabase is not connected.'; return;}
  const {data:{user}} = await supabaseClient.auth.getUser();
  if(!user){msg.textContent='Please log in before submitting a seller payment.'; auth('login'); return;}
  // Make sure the signed-in user has a profile row first.
  // The subscriptions.seller_id column references profiles.id.
  const {data:profile, error:profileReadError} = await supabaseClient
    .from('profiles')
    .select('id')
    .eq('id', user.id)
    .maybeSingle();

  if(profileReadError){
    msg.textContent = 'Could not check your account profile: ' + profileReadError.message;
    return;
  }

  if(!profile){
    const {error:profileInsertError} = await supabaseClient
      .from('profiles')
      .insert({
        id: user.id,
        email: user.email || '',
        role: 'buyer'
      });

    if(profileInsertError && profileInsertError.code !== '23505'){
      msg.textContent = 'Could not create your seller profile: ' + profileInsertError.message;
      return;
    }
  }

  const {error} = await supabaseClient.from('subscriptions').insert({
    seller_id:user.id,
    plan:selectedPlan,
    amount:PLAN_PRICES[selectedPlan],
    crypto:'USDT',
    network:'TRC20',
    tx_hash:tx,
    status:'pending'
  });

  if(error){
    msg.textContent='Could not submit payment: '+error.message;
    return;
  }

  msg.textContent='Payment submitted successfully. The admin will review your transaction.';
  document.getElementById('paymentTx').value='';
}

async function openAdmin(){
  if(!supabaseClient){
    alert('Supabase is not connected.');
    return;
  }
  const {data:{user}} = await supabaseClient.auth.getUser();
  if(!user){
    alert('Please log in with the admin account first.');
    auth('login');
    return;
  }
  if(user.email?.toLowerCase() !== ADMIN_EMAIL){
    alert('Admin access is restricted to the MarketHub admin account.');
    return;
  }
  document.getElementById('adminModal').classList.add('show');
  await loadPendingPosts();
}

async function loadPendingPosts(){
  const box = document.getElementById('pendingPosts');
  const status = document.getElementById('adminStatus');
  box.innerHTML = '<p class="empty">Loading pending posts...</p>';
  status.textContent = '';
  try{
    const {data, error} = await supabaseClient
      .from('products')
      .select('id,name,description,price,category,image_url,stock,approval_status,created_at,seller_id')
      .eq('approval_status','pending')
      .order('created_at',{ascending:false});
    if(error) throw error;
    status.textContent = `${data.length} pending`;
    if(!data.length){
      box.innerHTML = '<p class="empty">No pending posts.</p>';
      return;
    }
    box.innerHTML = data.map(p => `
      <article class="pending-post">
        <div class="pending-post-main">
          <div class="pending-post-image">${p.image_url ? `<img src="${esc(p.image_url)}" alt="">` : '🛍️'}</div>
          <div>
            <h3>${esc(p.name)}</h3>
            <p>${esc(p.description || 'No description provided.')}</p>
            <small>Category: ${esc(p.category || 'Other')} · Price: ${money(Number(p.price)||0)} · Stock: ${esc(p.stock ?? 0)}</small>
            <small>Seller: ${esc(p.seller_id || 'Unknown')}</small>
          </div>
        </div>
        <div class="pending-actions">
          <button class="primary approve-post" data-id="${p.id}">✓ Approve</button>
          <button class="secondary reject-post" data-id="${p.id}">✕ Reject</button>
        </div>
      </article>
    `).join('');
  }catch(err){
    box.innerHTML = `<p class="empty">Could not load pending posts: ${esc(err.message)}</p>`;
    status.textContent = 'Error';
  }
}

async function moderatePost(id, statusValue){
  if(!(await isAdminUser())){
    alert('Admin access required.');
    return;
  }
  const patch = statusValue === 'approved'
    ? {approval_status:'approved', active:true}
    : {approval_status:'rejected', active:false};

  const {error} = await supabaseClient.from('products').update(patch).eq('id', id);
  if(error){
    alert('Could not update post: ' + error.message);
    return;
  }
  await loadPendingPosts();
  alert(statusValue === 'approved' ? 'Post approved.' : 'Post rejected.');
}

function closeModal(modal){
  if(!modal) return;
  modal.classList.remove('show');
  modal.style.display='none';
  setTimeout(()=>{ if(!modal.classList.contains('show')) modal.style.removeProperty('display'); },0);
}

document.addEventListener('click',e=>{
  const closeBtn=e.target.closest('.close');
  if(closeBtn){
    e.preventDefault();
    e.stopPropagation();
    const modalId=closeBtn.dataset.close;
    closeModal(modalId ? document.getElementById(modalId) : closeBtn.closest('.modal'));
    return;
  }
  if(e.target.classList.contains('modal')){
    closeModal(e.target);
    return;
  }
  if(e.target.closest('#cartOpen'))openCart();
  let a=e.target.closest('.add');if(a)add(a.dataset.id);
  let c=e.target.closest('.category');if(c)filter(c.dataset.cat);
  if(e.target.closest('#accountOpen')||e.target.closest('#login'))auth('login');
  if(e.target.closest('#signup'))auth('signup');
  if(e.target.closest('#copyAddress')){navigator.clipboard?.writeText(document.getElementById('cryptoAddress').textContent);e.target.textContent='Copied!';setTimeout(()=>e.target.textContent='Copy address',1200)}
});
document.getElementById('searchForm').addEventListener('submit',e=>{e.preventDefault();let q=document.getElementById('searchInput').value.toLowerCase().trim();renderProducts(q?products.filter(p=>(p.name+' '+p.category).toLowerCase().includes(q)):products);document.getElementById('explore').scrollIntoView({behavior:'smooth'})});
document.getElementById('searchTop').onclick=()=>document.getElementById('searchInput').focus();
const menuOpen=document.getElementById('menuOpen');
const mobileMenu=document.getElementById('mobileMenu');
const closeMobileMenu=()=>{mobileMenu.classList.remove('show');mobileMenu.setAttribute('aria-hidden','true');menuOpen.setAttribute('aria-expanded','false')};
menuOpen.onclick=()=>{const open=!mobileMenu.classList.contains('show');mobileMenu.classList.toggle('show',open);mobileMenu.setAttribute('aria-hidden',String(!open));menuOpen.setAttribute('aria-expanded',String(open))};
document.getElementById('menuClose').onclick=closeMobileMenu;
document.querySelectorAll('[data-menu-link]').forEach(link=>link.addEventListener('click',closeMobileMenu));
document.getElementById('mobileCart').onclick=()=>{closeMobileMenu();openCart()};
document.getElementById('mobileAdmin').onclick=async()=>{closeMobileMenu();await openAdmin();};
mobileMenu.addEventListener('click',e=>{if(e.target===mobileMenu)closeMobileMenu()});
window.addEventListener('keydown',e=>{if(e.key==='Escape')closeMobileMenu()});

document.getElementById('authForm').addEventListener('submit',async e=>{e.preventDefault();let msg=document.getElementById('authMessage'),email=document.getElementById('authEmail').value,password=document.getElementById('authPassword').value;try{if(typeof supabaseClient==='undefined' || !supabaseClient){msg.textContent=supabaseConfigError ? 'Supabase connection error: '+supabaseConfigError : 'Supabase is not configured. Make sure the latest config.js is deployed.';return}let r=document.getElementById('authForm').dataset.mode==='login'?await supabaseClient.auth.signInWithPassword({email,password}):await supabaseClient.auth.signUp({email,password});if(r.error)throw r.error;msg.textContent='Success. Check your email if confirmation is enabled.'}catch(err){msg.textContent=err.message}});
document.getElementById('checkout').onclick=()=>openCart();
renderCategories();renderProducts();renderPlans();save();
document.querySelectorAll('.choose').forEach(btn => {
  btn.addEventListener('click', () => openPayment(btn.dataset.plan));
});

document.getElementById('refreshPending').onclick = loadPendingPosts;
document.getElementById('submitPayment').onclick = submitSubscriptionPayment;
document.getElementById('paymentCopy').onclick = async () => { try { await navigator.clipboard.writeText(PAYMENT_ADDRESS); document.getElementById('paymentCopy').textContent='Copied!'; setTimeout(()=>document.getElementById('paymentCopy').textContent='Copy address',1200); } catch(e) {} };
document.addEventListener('click', e => {
  const approve = e.target.closest('.approve-post');
  const reject = e.target.closest('.reject-post');
  if(approve) moderatePost(approve.dataset.id, 'approved');
  if(reject) moderatePost(reject.dataset.id, 'rejected');
});
